﻿using System.ComponentModel.DataAnnotations;

namespace SamaritanCore.ViewModels
{
    public class VolunteerViewModel
    {
        [Required(ErrorMessage = "Необходимо указать имя")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Необходимо указать фамилию")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Необходимо указать отчество")]
        public string Patronymic { get; set; }

        [Required(ErrorMessage = "Необходимо указать электронный адрес")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Необходимо указать пароль")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required(ErrorMessage = "Необходимо указать телефон")]
        [DataType(DataType.PhoneNumber)]
        public string PhoneNumber { get; set; }
    }
}
