﻿using System.ComponentModel.DataAnnotations;

namespace SamaritanCore.ViewModels
{
    public class AppRoleViewModel
    {
        [Required(ErrorMessage = "Необходимо указать имя")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Необходимо указать описание")]
        public string Description { get; set; }
    }
}
