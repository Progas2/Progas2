﻿using System.ComponentModel.DataAnnotations;

namespace SamaritanCore.ViewModels
{
    public class AppUserViewModel
    {
        [Required(ErrorMessage = "Необходимо указать имя")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Необходимо указать электронный адрес")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Необходимо указать телефон")]
        public string PhoneNumber { get; set; }
    }
}
