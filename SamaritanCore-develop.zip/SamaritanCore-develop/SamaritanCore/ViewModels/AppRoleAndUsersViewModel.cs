﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SamaritanCore.DataModel.Models;

namespace SamaritanCore.ViewModels
{
    public class AppRoleAndUsersViewModel
    {
        public ApplicationRole Role { get; set; }

        public IEnumerable<ApplicationUser> Users { get; set; }
    }
}
