﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamaritanCore.Utilities
{
    public class IndividualButton
    {
        public string ButtonClass { get; set; }
        public string Action { get; set; }
        public string Icon { get; set; }
        public string IconColor { get; set; }
        public string Tooltip { get; set; }

        public string UserId { get; set; }
        public string RoleId { get; set; }
        public string VolunteerId { get; set; }

        public string ActionParameters
        {
            get
            {
                var param = new StringBuilder(@"/");

                if (!string.IsNullOrEmpty(UserId))
                {
                    param.Append(UserId);
                }
                if (!string.IsNullOrEmpty(RoleId))
                {
                    param.Append(RoleId);
                }
                if (!string.IsNullOrEmpty(VolunteerId))
                {
                    param.Append(VolunteerId);
                }
                return param.ToString().Substring(0, param.Length);
            }
        }
    }
}
