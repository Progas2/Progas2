﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SamaritanCore.Utilities
{
    public class RoleNames
    {
        public const string RoleAdministrator = "Administrator";
        public const string RoleModerator = "Moderator";
        public const string RoleUser = "User";
        public const string RoleVolunteer = "Volunteer";
    }
}
