﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SamaritanCore.DataModel;
using SamaritanCore.DataModel.Models;
using SamaritanCore.ViewModels;

namespace SamaritanCore.Controllers
{
    public class RolesController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        private readonly SamaritanDbContext _db;

        public RolesController(
            UserManager<ApplicationUser> userManager,
            RoleManager<ApplicationRole> roleManager,
            SamaritanDbContext db)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _db = db;
        }

        //GET: Roles/Index
        public IActionResult Index()
        {
            return View(_db.Roles.ToList());
        }

        //GET: Roles/Create
        public IActionResult Create()
        {
            return View();
        }

        //POST: Roles/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(AppRoleViewModel appRoleViewModel)
        {
            if (ModelState.IsValid)
            {
                //var appRole = new ApplicationRole()
                //{
                //    Name = appRoleViewModel.Name,
                //    Description = appRoleViewModel.Description
                //};
                //_db.Add(appRole);
                //await _db.SaveChangesAsync();
                await _roleManager.CreateAsync(new ApplicationRole()
                {
                    Name = appRoleViewModel.Name,
                    Description = appRoleViewModel.Description
                });
                return RedirectToAction(nameof(Index));
            }

            return View(appRoleViewModel);
        }

        //GET: Roles/Details/id
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var role = await _db.Roles.SingleOrDefaultAsync(r => r.Id == id);
            if (role == null)
            {
                return NotFound();
            }

            var users = await _userManager.GetUsersInRoleAsync(role.Name);
            var appRoleAndUsersViewModel = new AppRoleAndUsersViewModel()
            {
                Role = role,
                Users = users
            };

            return View(appRoleAndUsersViewModel);
        }

        //GET: Roles/Edit/id
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var role = await _db.Roles.SingleOrDefaultAsync(r => r.Id == id);

            if (role == null)
            {
                return NotFound();
            }

            return View(role);
        }

        //POST: Roles/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, ApplicationRole role)
        {
            if (role.Id != id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                var roleFromDb = await _db.Roles.SingleOrDefaultAsync(r => r.Id == id);

                if (roleFromDb != null)
                {
                    roleFromDb.Description = role.Description;

                    await _db.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }

            return View(role);
        }

        //GET: Roles/Manage/id
        public async Task<IActionResult> Manage(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var role = await _db.Roles.SingleOrDefaultAsync(r => r.Id == id);
            if (role == null)
            {
                return NotFound();
            }

            return View(role);
        }

        //GET: Roles/Delete/id
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var role = await _db.Roles.SingleOrDefaultAsync(r => r.Id == id);
            if (role == null)
            {
                return NotFound();
            }

            return View(role);
        }

        //POST: Roles/Delete/id
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Remove(string id)
        {
            var role = await _db.Roles.SingleOrDefaultAsync(r => r.Id == id);
            _db.Roles.Remove(role);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
        }
    }
}