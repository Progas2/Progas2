﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SamaritanCore.DataModel;
using SamaritanCore.DataModel.Models;
using SamaritanCore.Utilities;
using SamaritanCore.ViewModels;

namespace SamaritanCore.Controllers
{
    public class VolunteersController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        private readonly SamaritanDbContext _db;

        public VolunteersController(
            UserManager<ApplicationUser> userManager,
            RoleManager<ApplicationRole> roleManager,
            SamaritanDbContext db)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _db = db;
        }

        //GET: Volunteers/Index
        public IActionResult Index()
        {
            return View(_db.Volunteers.ToList());
        }

        //GET: Volunteers/Create
        public IActionResult Create()
        {
            return View();
        }

        //POST: Volunteers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(VolunteerViewModel volunteerViewModel)
        {
            //TO DO: Check properties
            if (ModelState.IsValid)
            {
                var appUser = new ApplicationUser()
                {
                    UserName = volunteerViewModel.Email,
                    Email = volunteerViewModel.Email,
                    FirstName = volunteerViewModel.FirstName,
                    PhoneNumber = volunteerViewModel.PhoneNumber
                };

                var result = await _userManager.CreateAsync(appUser, volunteerViewModel.Password);

                if (result.Succeeded)
                {
                    if (await _roleManager.RoleExistsAsync(RoleNames.RoleVolunteer))
                    {
                        await _userManager.AddToRoleAsync(appUser, RoleNames.RoleVolunteer);
                    }

                    var volunteer = new Volunteer()
                    {
                        FirstName = volunteerViewModel.FirstName,
                        LastName = volunteerViewModel.LastName,
                        Patronymic = volunteerViewModel.Patronymic,
                        Email = volunteerViewModel.Email,
                        PhoneNumber = volunteerViewModel.PhoneNumber,
                        UserId = appUser.Id
                    };
                    _db.Add(volunteer);
                    await _db.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
            }

            return View(volunteerViewModel);
        }

        //GET: Volunteers/Details/id
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var volunteer = await _db.Volunteers.SingleOrDefaultAsync(v => v.Id == id);

            if (volunteer == null)
            {
                return NotFound();
            }

            return View(volunteer);
        }

        //GET: Volunteers/Edit/id
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var volunteer = await _db.Volunteers.SingleOrDefaultAsync(v => v.Id == id);

            if (volunteer == null)
            {
                return NotFound();
            }

            return View(volunteer);
        }

        //POST: Volunteers/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, Volunteer volunteer)
        {
            if (volunteer.Id != id)
            {
                return NotFound();
            }
            var volunteerFromDb = await _db.Volunteers.SingleOrDefaultAsync(u => u.Id == id);

            if (volunteerFromDb != null)
            {
                volunteerFromDb.FirstName = volunteer.FirstName;
                volunteerFromDb.LastName = volunteer.LastName;
                volunteerFromDb.Patronymic = volunteer.Patronymic;
                volunteerFromDb.PhoneNumber = volunteer.PhoneNumber;
                volunteerFromDb.Email = volunteer.Email;

                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(volunteer);
        }

        //GET: Volunteers/Manage/id
        public async Task<IActionResult> Manage(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var volunteer = await _db.Volunteers.SingleOrDefaultAsync(v => v.Id == id);
            if (volunteer == null)
            {
                return NotFound();
            }

            return View(volunteer);
        }

        //GET: Volunteers/Delete/id
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var volunteer = await _db.Volunteers.SingleOrDefaultAsync(v => v.Id == id);
            if (volunteer == null)
            {
                return NotFound();
            }

            return View(volunteer);
        }

        //POST: Volunteers/Delete/id
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Remove(string id)
        {
            var volunteer = await _db.Volunteers.SingleOrDefaultAsync(v => v.Id == id);
            _db.Volunteers.Remove(volunteer);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
        }
    }
}