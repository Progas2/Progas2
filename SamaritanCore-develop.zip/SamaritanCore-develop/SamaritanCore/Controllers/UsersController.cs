﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SamaritanCore.DataModel;
using SamaritanCore.DataModel.Models;
using SamaritanCore.ViewModels;

namespace SamaritanCore.Controllers
{
    public class UsersController : Controller
    {
        private readonly SamaritanDbContext _db;

        public UsersController(SamaritanDbContext db)
        {
            _db = db;
        }

        //GET: Users/Index
        public IActionResult Index()
        {
            return View(_db.Users.ToList());
        }

        //GET: Users/Create
        public IActionResult Create()
        {
            return View();
        }

        //POST: Users/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(AppUserViewModel appUserViewModel)
        {
            if (ModelState.IsValid)
            {
                var appUser = new ApplicationUser()
                {
                    FirstName = appUserViewModel.FirstName,
                    Email = appUserViewModel.Email,
                    PhoneNumber = appUserViewModel.PhoneNumber
                };
                _db.Add(appUser);
                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(appUserViewModel);
        }

        //GET: Users/Details/id
        public async Task<IActionResult> Details(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _db.Users.SingleOrDefaultAsync(u => u.Id == id);

            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        //GET: Users/Edit/id
        public async Task<IActionResult> Edit(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _db.Users.SingleOrDefaultAsync(u => u.Id == id);

            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        //POST: Users/Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(string id, ApplicationUser user)
        {
            if (user.Id != id)
            {
                return NotFound();
            }
            var userFromDb = await _db.Users.SingleOrDefaultAsync(u => u.Id == id);

            if (userFromDb != null)
            {
                userFromDb.FirstName = user.FirstName;
                userFromDb.PhoneNumber = user.PhoneNumber;
                userFromDb.Email = user.Email;

                await _db.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(user);
        }

        //GET: Users/Manage/id
        public async Task<IActionResult> Manage(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _db.Users.SingleOrDefaultAsync(u => u.Id == id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        //GET: Users/Delete/id
        public async Task<IActionResult> Delete(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var user = await _db.Users.SingleOrDefaultAsync(u => u.Id == id);
            if (user == null)
            {
                return NotFound();
            }

            return View(user);
        }

        //POST: Users/Delete/id
        [HttpPost,ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Remove(string id)
        {
            var user = await _db.Users.SingleOrDefaultAsync(u => u.Id == id);
            _db.Users.Remove(user);
            await _db.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _db.Dispose();
            }
        }
    }
}